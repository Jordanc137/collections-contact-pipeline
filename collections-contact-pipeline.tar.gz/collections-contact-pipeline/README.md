# Collections Contact Analytics Pipeline

A production Python pipeline for collections analytics teams. Consolidates call detail records (CDR) from multiple dialing platforms into a unified master, enriches them with daily portfolio assignments and payment data, and produces interactive HTML dashboards and daily Excel reports.

Built and maintained in a real collections operation with 13,000–17,000 accounts under management per day across 7 contact channels.

---

## What it does

**Three interconnected systems:**

| System | Purpose | Output |
|--------|---------|--------|
| `pipeline/` | CDR ingestion, enrichment, aggregation | HTML dashboard + Excel |
| `optimization/` | Daily account prioritization | Excel with 4 sheets |
| `core/` | Shared I/O and utilities | Parquet I/O, phone classification |

**Contact channels supported:**
- Predictive dialer (Vicidial-based) — with RPC (Right Party Contact) tracking
- Robocall / Blaster — ES_MENSAJE flag as machine-contact proxy
- IVR
- Blaster CHOCK (alternate robocall platform)
- MuttechMX (alternate predictive platform)
- AI chat / WhatsApp (Calixta)
- SMS (reserved)

---

## Architecture

```
Input files (raw CDRs, daily assignments, payments)
        │
        ▼
[Step 1] consolidate_cdr.py       ← incremental, 7 format parsers
        │  cdr_master.parquet
        ▼
[Step 2] enrich_campaigns.py      ← cross-reference assignments → campaigns, slots
        │  cdr_enriched.parquet
        ▼
[Step 3] aggregate.py             ← KPIs per tool/campaign/week/day
        │  dashboard_data.json
        │
        ├── [Step E] strategy.py          (objective vs actual)
        ├── [Step 7] excluded_campaigns.py
        ├── [Step 4+4b] payments.py       (payment rate by contact intensity bucket)
        ├── [Step 8] best_hour.py         (Wilson-score optimal contact hour)
        └── [Step 9] payment_cutoff.py
                │  (all JSON outputs)
                ▼
[Step 5] build_dashboard.py       ← assembles final HTML dashboard
```

Steps E/7/4/8/9 run in **parallel** via `ThreadPoolExecutor` (independent, each reads only `cdr_enriched.parquet` + its own inputs). Step 5 waits for all.

**Optimization pipeline** (separate, runs daily):
```
H3: cross_day_hour.py  →  H4: rename_campaigns.py  →  H5: tool_optimization.py
```
H5 consumes `cdr_enriched.parquet` from the main pipeline and the daily assignment file. It validates that the prioritization file is fresher than the latest assignment before proceeding.

---

## Key engineering decisions

### Incremental deduplication on `(DATE, TOOL)` composite key
Not just `DATE`. Deduplication on a single date key silently drops entire tools for already-processed dates when files for different tools arrive on different days. The composite key is preloaded from Parquet using columnar reads (3 columns only, not the full file).

### Format detection by column headers only — never by filename
Seven different input formats are detected solely by their header signature. Filename-based detection failed in production when the same platform changed its naming convention three times across three sample files.

### Parquet with streaming writes
`cdr_master` and `cdr_enriched` are stored as Parquet (via `pyarrow`) instead of CSV. The core issue was buffering all rows before writing — at production scale (~weeks of history) this caused ~4 GB RAM usage and disk swapping. `ParquetDictWriter` writes in batches of 100k rows. The append path (`mode="a"`) streams both the existing file and new rows without loading either completely.

### Windows file handle fix
`os.replace()` on Windows raises `PermissionError (WinError 5)` if any `ParquetFile` object remains open. All `pq.ParquetFile` instances are explicitly `.close()`d before the rename — not relying on GC timing, which differs between Linux and Windows.

### `fechas_existentes` updated inside the loop
The set of processed (date, tool) pairs is updated after each file is processed, not just loaded once before the loop. The original single-load caused duplication on re-runs when new files for already-started dates were added.

### IFT bisect list precomputed at load time
Phone number classification (mobile/landline) uses binary search over 178,151 numbering blocks from Mexico's IFT national numbering plan. The search list (`_cache_inicios`) is built once at load time — rebuilding it on every classification call caused timeouts at real scale.

### Missing data is always `"sin dato aún"` — never coerced to zero
If a tool has no data for a given day, it displays as "no data yet" in the dashboard. A zero would be analytically incorrect (absence of evidence ≠ zero activity).

### `idUnico` always typed as string
Account identifiers are always treated as strings throughout the pipeline — no implicit numeric coercion anywhere.

---

## Project structure

```
collections-contact-pipeline/
├── core/
│   ├── cdr_io.py              # Parquet I/O module (streaming read/write)
│   └── phone_classifier.py    # Mobile/landline classification via numbering plan
├── pipeline/
│   ├── run_pipeline.py        # Orchestrator (sequential + parallel phases)
│   ├── step1_consolidate.py   # CDR ingestion (7 format parsers)
│   ├── step2_enrich.py        # Campaign/assignment enrichment
│   ├── step3_aggregate.py     # KPI aggregation
│   ├── step4_payments.py      # Payment rate by contact intensity bucket
│   ├── step4b_payment_dist.py # Payment distribution breakdown
│   ├── step5_dashboard.py     # HTML dashboard builder
│   ├── step6_no_contact.py    # Accounts with zero contact attempts
│   ├── step7_excluded.py      # Excluded campaign analysis
│   ├── step8_best_hour.py     # Optimal contact hour (Wilson score CI)
│   ├── stepE_strategy.py      # Strategy: objective vs actual
│   └── templates/
│       ├── dashboard.html
│       └── strategy.html
├── optimization/
│   ├── stepH3_cross_day_hour.py   # Historical payment day/hour patterns
│   ├── stepH4_rename_campaigns.py # Campaign catalog normalization
│   └── stepH5_tool_optimizer.py   # Best tool per account (4-sheet Excel)
├── utils/
│   ├── diagnose_master.py     # Row counts per date+tool (debug)
│   └── purge_date.py          # Remove specific dates to force reprocessing
├── docs/
│   ├── ARCHITECTURE.md
│   ├── INPUT_FORMATS.md
│   └── STATUS_CATALOG.md
├── sample_data/
│   └── README.md              # Format descriptions + synthetic examples
├── config_example.py          # Configuration template (rename to config.py)
├── requirements.txt
└── README.md
```

---

## Input formats

| Format | Source | Detection (by header) |
|--------|--------|----------------------|
| CDR Systems XLSX | Dialer export | `DURACION SEG`, `CATEGORIA LLAMADA` present |
| Operations XLSX | Daily ops report | `FECHA INICIO Y HORA`, `PHONE NUMBER`, `STATUS` |
| Vicidial TXT | `EXPORT_CALL_REPORT` | `call_date`, `phone_number_dialed` |
| IA CSV | AI calls | `campaign_date`, `answered_by`, `contact_f_id` |
| WhatsApp CSV | Chat platform | `Teléfono`, `Resultado`, `Fecha de inicio` |
| Blaster CHOCK CSV | Alt robocall | `Estado`, `Duración`, `telefono`, `Campaign ID` |
| MuttechMX XLSX | Alt predictive | `FechaLlamada`, `TelefonoMarcado`, `Estatus` |

---

## Status → Category catalog

All STATUS codes are normalized to one of 5 categories:

| Category | Meaning |
|----------|---------|
| `Contestada` | Answered (useful contact) |
| `Contestada corta` | Answered but very short — likely voicemail/hangup |
| `Tono` | Ringing, busy, dropped |
| `Descartar` | Answering machine, disconnected, invalid number |
| `Sin datos` | Unrecognized status — pipeline flags and continues |

RPC states (Predictivo only): `COL`, `CTT`, `SALE`, `PDPP`, `CALLBK`, etc. — contact with the actual account holder confirmed by agent.

Full catalog in `docs/STATUS_CATALOG.md`.

---

## Phone classification

Mobile/landline classification uses Mexico's IFT (Federal Telecommunications Institute) National Numbering Plan — 178,151 numbering blocks, binary search via `bisect`. Returns `MOVIL`, `FIJO`, or `SIN_DETERMINAR` (never guesses).

The plan file is not included (download from [IFT SNS portal](https://sns.ift.org.mx)). Without it, the pipeline continues normally — classification columns simply show `SIN_DETERMINAR`.

---

## Setup

```bash
pip install pandas pyarrow openpyxl python-calamine
```

`python-calamine` is optional but recommended — reads XLSX ~10–15x faster than openpyxl (Rust-based parser). The pipeline falls back to openpyxl automatically if not installed.

Copy `config_example.py` → `config.py` and set your folder paths.

```bash
# Run full pipeline
python pipeline/run_pipeline.py

# Run optimization (separate, after main pipeline)
python optimization/stepH3_cross_day_hour.py
python optimization/stepH4_rename_campaigns.py
python optimization/stepH5_tool_optimizer.py
```

---

## Dashboard outputs

The HTML dashboard includes:

- **KPI cards** — contact intensity, answer rate, RPC rate per tool
- **Coverage table** — per phone slot (phone1–phone4) per day, per tool
- **Intensity distribution** — accounts by contact attempt bucket (1, 2–3, 4–6, 7–10, 11+)
- **Payment rate by intensity** — does more contact = more payments?
- **Best contact hour** — Wilson-score confidence interval, per campaign and day
- **Excluded campaigns** — same methodology, separate tab
- **Strategy tab** — objective vs actual attempt counts per segment/tool

---

## Optimization outputs

Daily Excel with 4 sheets:

1. **Tool Recommendation** — best tool per account based on CDR contact history
2. **Age-Based Recommendation** — channel suggestion by generational cohort (cross-referenced against real contact evidence; evidence always wins over demographic assumption)
3. **Payment Behavior Classification** — Positive / Regular / Negative / Insufficient data (scoring system using payment history trend + current delinquency + contactability)
4. **Methodology & Sources** — full documentation of how each sheet was calculated

---

## Utility scripts

```bash
# Show row counts per date+tool in the master (diagnose missing dates)
python utils/diagnose_master.py

# Remove a specific date to force reprocessing
python utils/purge_date.py 2026-08-13
```

---

## Design principles

- **No filename-based format detection** — headers only
- **No zero-filling of missing data** — explicit "no data" labels
- **No hardcoded paths** — all paths derived from script location or `config.py`
- **Explicit file handle closing** — before any `os.replace()` (Windows compatibility)
- **Incremental by default** — re-running never duplicates data
- **Campaign exclusions in two places** — assignment loading AND CDR enrichment (defense-in-depth)

---

## License

MIT
