# =============================================================================
# purge_date.py - Remove specific (DATE, TOOL) combinations from cdr_master
#
# Forces reprocessing of a date by deleting its rows from the master.
# After purging, re-run step1_consolidate.py to re-ingest from source files.
#
# Usage:
#   python utils/purge_date.py 2026-08-13
#   python utils/purge_date.py 2026-08-13 --tool Blaster
#   python utils/purge_date.py 2026-08-13 --dry-run
# =============================================================================
import os
import sys
import argparse
import pyarrow.parquet as pq
import pyarrow as pa

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import config
from core import cdr_io

MASTER_PATH = os.path.join(config.OUTPUT_FOLDER, config.MASTER_PARQUET)


def main():
    parser = argparse.ArgumentParser(description="Remove date rows from cdr_master.parquet")
    parser.add_argument("date", help="Date to purge (YYYY-MM-DD)")
    parser.add_argument("--tool", help="Optional: only purge this tool")
    parser.add_argument("--dry-run", action="store_true",
                        help="Show what would be removed without writing anything")
    args = parser.parse_args()

    if not os.path.exists(MASTER_PATH):
        print(f"[ERROR] Master not found: {MASTER_PATH}")
        sys.exit(1)

    print(f"Reading {MASTER_PATH} ...")
    kept = []
    removed = 0

    for row in cdr_io.read_parquet_rows(MASTER_PATH):
        if row["DATE"] == args.date:
            if args.tool is None or row["TOOL"] == args.tool:
                removed += 1
                continue
        kept.append(row)

    if removed == 0:
        label = f"{args.date}" + (f" / {args.tool}" if args.tool else "")
        print(f"No rows found for {label} — nothing to purge.")
        return

    print(f"Rows to remove: {removed:,}")
    print(f"Rows to keep:   {len(kept):,}")

    if args.dry_run:
        print("[DRY RUN] No changes written.")
        return

    confirm = input(f"Purge {removed:,} rows? [y/N] ").strip().lower()
    if confirm != "y":
        print("Aborted.")
        return

    fieldnames = cdr_io.get_parquet_columns(MASTER_PATH)
    tmp_path = MASTER_PATH + ".tmp_purge"

    with cdr_io.ParquetDictWriter(tmp_path, fieldnames, mode="w") as w:
        w.writeheader()
        for row in kept:
            w.writerow(row)

    os.replace(tmp_path, MASTER_PATH)
    print(f"Done. Purged {removed:,} rows. Re-run step1_consolidate.py to re-ingest.")


if __name__ == "__main__":
    main()
