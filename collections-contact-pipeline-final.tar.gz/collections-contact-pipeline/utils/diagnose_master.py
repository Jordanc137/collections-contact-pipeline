# =============================================================================
# diagnose_master.py - Row counts per (DATE, TOOL) in cdr_master.parquet
#
# Useful for verifying which dates and tools have been processed, detecting
# gaps, and confirming that incremental runs added what was expected.
#
# Usage:
#   python utils/diagnose_master.py
#   python utils/diagnose_master.py --date 2026-08-13
#   python utils/diagnose_master.py --tool Blaster
# =============================================================================
import os
import sys
import argparse
from collections import defaultdict

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import config
from core import cdr_io

MASTER_PATH = os.path.join(config.OUTPUT_FOLDER, config.MASTER_PARQUET)


def main():
    parser = argparse.ArgumentParser(description="Diagnose cdr_master.parquet contents")
    parser.add_argument("--date", help="Filter to a specific date (YYYY-MM-DD)")
    parser.add_argument("--tool", help="Filter to a specific tool name")
    args = parser.parse_args()

    if not os.path.exists(MASTER_PATH):
        print(f"[ERROR] Master not found: {MASTER_PATH}")
        sys.exit(1)

    print(f"Reading {MASTER_PATH} ...")
    counts = defaultdict(int)
    total = 0

    cols = cdr_io.read_parquet_columns(MASTER_PATH, ["DATE", "TOOL"])
    for date, tool in zip(cols["DATE"], cols["TOOL"]):
        if args.date and date != args.date:
            continue
        if args.tool and tool != args.tool:
            continue
        counts[(date, tool)] += 1
        total += 1

    if not counts:
        print("No records match the filter.")
        return

    print(f"\n{'DATE':<14} {'TOOL':<20} {'ROWS':>10}")
    print("-" * 46)
    for (date, tool), n in sorted(counts.items()):
        print(f"{date:<14} {tool:<20} {n:>10,}")
    print("-" * 46)
    print(f"{'TOTAL':<34} {total:>10,}")

    dates = sorted({d for d, _ in counts})
    tools = sorted({t for _, t in counts})
    print(f"\nDates: {dates[0]} → {dates[-1]} ({len(dates)} unique)")
    print(f"Tools: {', '.join(tools)}")


if __name__ == "__main__":
    main()
