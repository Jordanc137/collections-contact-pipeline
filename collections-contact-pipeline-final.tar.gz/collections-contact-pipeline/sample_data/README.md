# Sample Data

Real CDR files, assignment files, and payment files are not included (confidential).

This directory contains format descriptions and synthetic mini-examples so you
can test the pipeline without real data.

---

## Synthetic examples

### Format B — Operations XLSX (synthetic)

```
FECHA INICIO Y HORA       | PHONE NUMBER | STATUS | CAMPAIGN ID | CUENTA
2026-08-13 09:15:00       | 5512345678   | COL    | CB001       | ACC001
2026-08-13 09:17:32       | 5587654321   | AB     | CB001       | ACC002
2026-08-13 09:20:11       | 5511112222   | AA     | CP001       | ACC003
```

### Format C — Vicidial TXT (synthetic, tab-delimited)

```
call_date	call_time	phone_number_dialed	status	campaign_id	lead_id	length_in_sec
2026-08-13	09:15:00	5512345678	COL	CP001	ACC001	87
2026-08-13	09:18:22	5587654321	AB	CP001	ACC002	0
```

### Format F — Blaster CHOCK CSV (synthetic)

```
Hora,Fecha,Estado,Duración,telefono,Campaign ID
09:15,2026-08-13,CONTESTADA,45,5512345678,BC001
09:17,2026-08-13,NO CONTESTA,0,5587654321,BC001
09:20,2026-08-13,COMPLETADO,120,5511112222,BC001
```

### Assignment file (synthetic)

```
idUnico,idCampania,nombre,telefono1,telefono2,telefono3,telefono4,saldo
ACC001,1001,JUAN PEREZ,5512345678,5598765432,,, 4500.00
ACC002,1001,MARIA LOPEZ,5587654321,,,, 2100.50
ACC003,1002,PEDRO RUIZ,5511112222,5533334444,,, 8900.00
```

### Payment file (synthetic)

```
idUnico,idCampania,abonoTotal,montoRequerido
ACC001,1001,500.00,500.00
ACC003,1002,300.00,450.00
```

---

## Creating test data

To run the pipeline against synthetic data:

1. Create the folder structure matching `config.py` `INPUT_FOLDERS`
2. Place synthetic XLSX/CSV files with the correct headers (see above)
3. Place a synthetic assignment file in `ASSIGNMENTS_FOLDER` named
   `ASIGNACIONES_13082026.csv` (date format: DDMMYYYY)
4. Run `python pipeline/run_pipeline.py`

The pipeline will process the synthetic files and produce `cdr_master.parquet`,
`cdr_enriched.parquet`, and the dashboard JSON outputs.

Phone classification (`phone_classifier.py`) will return `UNKNOWN` for all
numbers unless you also provide the national numbering plan CSV — which is fine
for testing.
